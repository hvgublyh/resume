var Mock = require('mockjs');

const CARDS = Mock.mock({
  "data|5": [{
    id: '@guid',
    name: '@cword(2,10)',
    city: '@city',
    contact: /\d{8}/,
    production: '@cword(6,10)',
    company: '@cword(6,10)',
    email: '@email',
    industry: '@cword(6,10)',
    position: '@cword(6,10)',
    budget: '@cword(6,10)',
    requirement: '@cword(60,100)',
    createTime: '@date',
    status: "@integer(1, 5)",
    lastUpdate: '@date',
  }],
  total: 5,
});

const Alter = Mock.mock({
  success: '@boolean',
  author: '@boolean',
})

const API = () => {
  return {
    'mock': CARDS,
    'alter': Alter,
  }
};

module.exports = API;